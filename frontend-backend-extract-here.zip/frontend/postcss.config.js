module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
        // ... other plugins if any ...
    },
}
