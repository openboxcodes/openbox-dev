export const jsonOptions = ['str', 'float', 'int']
