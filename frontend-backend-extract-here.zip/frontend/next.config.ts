module.exports = {
    reactStrictMode: true,
    // Add any other configurations here
}
